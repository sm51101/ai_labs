<?php
/** @var \App\Service\Router $router */

$title = 'Create New Country';
$bodyClass = 'create';

ob_start(); ?>
    <h1><?= $title ?></h1>

    <form method="post" class="create-form">
        <!-- Name Input -->
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <!-- Gen1 Checkbox -->
        <label for="gen1">Gen1:</label>
        <input type="checkbox" id="gen1" name="gen1">

        <!-- Gen2 Checkbox -->
        <label for="gen2">Gen2:</label>
        <input type="checkbox" id="gen2" name="gen2">

        <!-- Gen3 Checkbox -->
        <label for="gen3">Gen3:</label>
        <input type="checkbox" id="gen3" name="gen3">

        <!-- Gen4 Checkbox -->
        <label for="gen4">Gen4:</label>
        <input type="checkbox" id="gen4" name="gen4">

        <!-- Submit Button -->
        <button type="submit">Create</button>
    </form>

    <ul class="action-list">
        <li><a href="<?= $router->generatePath('sv-country-index') ?>">Back to list</a></li>
    </ul>

<?php $main = ob_get_clean();

include __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'base.html.php';
