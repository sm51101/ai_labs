<?php
/** @var \App\Model\SVCountry $country */
/** @var \App\Service\Router $router */

$title = "Edit Country: {$country->getName()} ({$country->getId()})";
$bodyClass = "edit";

ob_start(); ?>
    <h1><?= $title ?></h1>

    <form method="post" class="edit-form">
        <!-- Name Input -->
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?= htmlspecialchars($country->getName()) ?>" required>

        <!-- Gen1 Checkbox -->
        <label for="gen1">Gen1:</label>
        <input type="checkbox" id="gen1" name="gen1" <?= $country->isGen1() ? 'checked' : '' ?>>

        <!-- Gen2 Checkbox -->
        <label for="gen2">Gen2:</label>
        <input type="checkbox" id="gen2" name="gen2" <?= $country->isGen2() ? 'checked' : '' ?>>

        <!-- Gen3 Checkbox -->
        <label for="gen3">Gen3:</label>
        <input type="checkbox" id="gen3" name="gen3" <?= $country->isGen3() ? 'checked' : '' ?>>

        <!-- Gen4 Checkbox -->
        <label for="gen4">Gen4:</label>
        <input type="checkbox" id="gen4" name="gen4" <?= $country->isGen4() ? 'checked' : '' ?>>

        <!-- Submit Button -->
        <button type="submit">Save Changes</button>
    </form>

    <ul class="action-list">
        <li><a href="<?= $router->generatePath('sv-country-index') ?>">Back to list</a></li>
        <li>
            <form action="<?= $router->generatePath('sv-country-delete', ['id' => $country->getId()]) ?>" method="post">
                <input type="submit" value="Delete" onclick="return confirm('Are you sure you want to delete this country?')">
                <input type="hidden" name="action" value="sv-country-delete">
                <input type="hidden" name="id" value="<?= $country->getId() ?>">
            </form>
        </li>
    </ul>

<?php $main = ob_get_clean();

include __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'base.html.php';
