<?php
/** @var \App\Model\SVCountry $country */
/** @var \App\Service\Router $router */

$title = "Country Details - {$country->getName()}";
$bodyClass = 'show';

ob_start(); ?>
    <h1>Country Details</h1>

    <p><strong>Name:</strong> <?= htmlspecialchars($country->getName()) ?></p>
    <p><strong>Gen1:</strong> <?= $country->isGen1() ? 'Yes' : 'No' ?></p>
    <p><strong>Gen2:</strong> <?= $country->isGen2() ? 'Yes' : 'No' ?></p>
    <p><strong>Gen3:</strong> <?= $country->isGen3() ? 'Yes' : 'No' ?></p>
    <p><strong>Gen4:</strong> <?= $country->isGen4() ? 'Yes' : 'No' ?></p>

    <ul class="action-list">
        <li><a href="<?= $router->generatePath('sv-country-index') ?>">Back to list</a></li>
        <li><a href="<?= $router->generatePath('sv-country-edit', ['id' => $country->getId()]) ?>">Edit</a></li>
        <li><a href="<?= $router->generatePath('sv-country-delete', ['id' => $country->getId()]) ?>" onclick="return confirm('Are you sure you want to delete this country?');">Delete</a></li>
    </ul>

<?php $main = ob_get_clean();

include __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'base.html.php';
