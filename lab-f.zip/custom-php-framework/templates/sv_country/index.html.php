<?php
/** @var \App\Model\SVCountry[] $countries */
/** @var \App\Service\Router $router */

$title = 'SV Countries';
$bodyClass = 'index';

ob_start(); ?>
    <style>
        table {
            border-collapse: separate;
            border-spacing: 10px;
        }

        table tr:first-child {
            font-weight: bold;
        }

        table tr td a {
            color: blue;
        }

        .add-country {
            color:  blue;
            border: 2px solid blue;
            border-radius: 20% 20%;
            padding: 5px;
            background-color: #e6ffff;
        }
    </style>
    <h1>SV Countries</h1>
    <p>Here is a list showing which countries have official Street View coverage and in what camera generation.</p>
    <br>
    <a href="<?= $router->generatePath('sv-country-create') ?>" class="add-country">Add New Country</a>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Gen1</th>
            <th>Gen2</th>
            <th>Gen3</th>
            <th>Gen4</th>
            <th>Actions</th>
        </tr>
        <?php if (!empty($countries)): ?>
            <?php foreach ($countries as $country): ?>
                <tr>
                    <td><?= $country->getId() ?></td>
                    <td><?= htmlspecialchars($country->getName()) ?></td>
                    <td><?= $country->isGen1() ? 'Yes' : 'No' ?></td>
                    <td><?= $country->isGen2() ? 'Yes' : 'No' ?></td>
                    <td><?= $country->isGen3() ? 'Yes' : 'No' ?></td>
                    <td><?= $country->isGen4() ? 'Yes' : 'No' ?></td>
                    <td>
                        <a href="<?= $router->generatePath('sv-country-show', ['id' => $country->getId()]) ?>">View</a> |
                        <a href="<?= $router->generatePath('sv-country-edit', ['id' => $country->getId()]) ?>">Edit</a> |
                        <a href="<?= $router->generatePath('sv-country-delete', ['id' => $country->getId()]) ?>" onclick="return confirm('Are you sure?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="7">No countries found.</td>
            </tr>
        <?php endif; ?>
    </table>

<?php $main = ob_get_clean();

include __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'base.html.php';
