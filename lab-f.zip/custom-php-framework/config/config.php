<?php
$config = [];
$config['db_dsn'] = 'sqlite:C:/Users/Michal Sowa/Desktop/AI1/lab-ff/custom-php-framework/data.db';
$config['db_user'] = '';
$config['db_pass'] = '';
