<?php
namespace App\Controller;

use App\Exception\NotFoundException;
use App\Model\SVCountry;
use App\Service\Router;
use App\Service\Templating;

class SVCountryController
{
    public function indexAction(Templating $templating, Router $router): ?string
    {
        $countries = SVCountry::findAll();

        $html = $templating->render('sv_country/index.html.php', [
            'countries' => $countries,
            'router' => $router,
        ]);
        return $html;
    }

    public function createAction(?array $requestPost, Templating $templating, Router $router): ?string
    {
        if ($requestPost) {

            $country = SVCountry::fromArray($requestPost);
            // @todo missing validation
            $country->save();

            $path = $router->generatePath('sv-country-index');
            $router->redirect($path);
            return null;
        } else {
            $country = new SVCountry();
        }

        $html = $templating->render('sv_country/create.html.php', [
            'country' => $country,
            'router' => $router,
        ]);
        return $html;
    }

    public function editAction(int $countryId, ?array $requestPost, Templating $templating, Router $router): ?string
    {
        $country = SVCountry::find($countryId);
        if (! $country) {
            throw new NotFoundException("Missing country with id $countryId");
        }

        if ($requestPost) {
            $country->fill($requestPost);
            // @todo brak walidacji
            $country->save();

            $path = $router->generatePath('sv-country-index');
            $router->redirect($path);
            return null;
        }

        $html = $templating->render('sv_country/edit.html.php', [
            'country' => $country,
            'router' => $router,
        ]);
        return $html;
    }

    public function showAction(int $countryId, Templating $templating, Router $router): ?string
    {
        $country = SVCountry::find($countryId);
        if (! $country) {
            throw new NotFoundException("Missing country with id $countryId");
        }

        $html = $templating->render('sv_country/show.html.php', [
            'country' => $country,
            'router' => $router,
        ]);
        return $html;
    }


    public function deleteAction(int $countryId, Router $router): ?string
    {
        $country = SVCountry::find($countryId);
        if (! $country) {
            throw new NotFoundException("Missing country with id $countryId");
        }

        $country->delete();

        $path = $router->generatePath('sv-country-index');
        $router->redirect($path);
        return null;
    }
}
