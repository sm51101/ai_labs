<?php
namespace App\Model;

use App\Service\Config;

class SVCountry
{
    private ?int $id = null;
    private ?string $name = null;
    private bool $gen1 = false;
    private bool $gen2 = false;
    private bool $gen3 = false;
    private bool $gen4 = false;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(?int $id): SVCountry
    {
        $this->id = $id;
        return $this;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): SVCountry
    {
        $this->name = $name;
        return $this;
    }

    public function isGen1(): bool
    {
        return $this->gen1;
    }

    public function setGen1(bool $gen1): SVCountry
    {
        $this->gen1 = $gen1;
        return $this;
    }

    public function isGen2(): bool
    {
        return $this->gen2;
    }

    public function setGen2(bool $gen2): SVCountry
    {
        $this->gen2 = $gen2;
        return $this;
    }

    public function isGen3(): bool
    {
        return $this->gen3;
    }

    public function setGen3(bool $gen3): SVCountry
    {
        $this->gen3 = $gen3;
        return $this;
    }

    public function isGen4(): bool
    {
        return $this->gen4;
    }

    public function setGen4(bool $gen4): SVCountry
    {
        $this->gen4 = $gen4;
        return $this;
    }

    public static function fromArray($array): SVCountry
    {
        $country = new self();
        $country->fill($array);
        return $country;
    }

    public function fill($array): SVCountry
    {
        if (isset($array['id'])) {
            $this->setId($array['id']);
        }
        if (isset($array['name'])) {
            $this->setName($array['name']);
        }
        if (isset($array['gen1'])) {
            $this->setGen1((bool) $array['gen1']);
        }
        if (isset($array['gen2'])) {
            $this->setGen2((bool) $array['gen2']);
        }
        if (isset($array['gen3'])) {
            $this->setGen3((bool) $array['gen3']);
        }
        if (isset($array['gen4'])) {
            $this->setGen4((bool) $array['gen4']);
        }
        return $this;
    }

    public static function findAll(): array
    {
        $pdo = new \PDO(Config::get('db_dsn'), Config::get('db_user'), Config::get('db_pass'));
        $sql = 'SELECT * FROM sv_countries';
        $statement = $pdo->prepare($sql);
        $statement->execute();

        $countries = [];
        $countriesArray = $statement->fetchAll(\PDO::FETCH_ASSOC);
        foreach ($countriesArray as $countryArray) {
            $countries[] = self::fromArray($countryArray);
        }
        return $countries;
    }

    public static function find($id): ?SVCountry
    {
        $pdo = new \PDO(Config::get('db_dsn'), Config::get('db_user'), Config::get('db_pass'));
        $sql = 'SELECT * FROM sv_countries WHERE id = :id';
        $statement = $pdo->prepare($sql);
        $statement->execute(['id' => $id]);

        $countryArray = $statement->fetch(\PDO::FETCH_ASSOC);
        if (!$countryArray) {
            return null;
        }
        return SVCountry::fromArray($countryArray);
    }

    public function save(): void
    {
        $pdo = new \PDO(Config::get('db_dsn'), Config::get('db_user'), Config::get('db_pass'));
        if (!$this->getId()) {
            $sql = "INSERT INTO sv_countries (name, gen1, gen2, gen3, gen4) VALUES (:name, :gen1, :gen2, :gen3, :gen4)";
            $statement = $pdo->prepare($sql);
            $statement->execute([
                'name' => $this->getName(),
                'gen1' => $this->isGen1(),
                'gen2' => $this->isGen2(),
                'gen3' => $this->isGen3(),
                'gen4' => $this->isGen4(),
            ]);
            $this->setId($pdo->lastInsertId());
        } else {
            $sql = "UPDATE sv_countries SET name = :name, gen1 = :gen1, gen2 = :gen2, gen3 = :gen3, gen4 = :gen4 WHERE id = :id";
            $statement = $pdo->prepare($sql);
            $statement->execute([
                'name' => $this->getName(),
                'gen1' => $this->isGen1(),
                'gen2' => $this->isGen2(),
                'gen3' => $this->isGen3(),
                'gen4' => $this->isGen4(),
                'id' => $this->getId(),
            ]);
        }
    }

    public function delete(): void
    {
        $pdo = new \PDO(Config::get('db_dsn'), Config::get('db_user'), Config::get('db_pass'));
        $sql = "DELETE FROM sv_countries WHERE id = :id";
        $statement = $pdo->prepare($sql);
        $statement->execute(['id' => $this->getId()]);
    }
}
