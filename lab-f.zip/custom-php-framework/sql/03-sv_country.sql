CREATE TABLE IF NOT EXISTS sv_countries (
                                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                                            name TEXT NOT NULL,
                                            gen1 BOOLEAN NOT NULL,
                                            gen2 BOOLEAN NOT NULL,
                                            gen3 BOOLEAN NOT NULL,
                                            gen4 BOOLEAN NOT NULL
);